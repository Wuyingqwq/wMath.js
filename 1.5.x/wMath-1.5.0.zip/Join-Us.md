# Join us
# 加入我们
## If you want to join us,you need to meet the following conditions:
## 如果你想加入我们，你需要满足以下条件：

- Have its own project and is useful.
- 有自己的项目,是有用的。
- Have a GitHub account.
- 有一个GitHub帐户。
- Have the ability to maintain wMath.
- 有能力维护wMath。
- Can use JavaScript.
- 可以使用JavaScript。
- Have your own ideas.
- 有自己的想法

## If you meet the above conditions,you can send a email to join-us@wyjs.fun
## 如果你符合上面的条件,你可以发送一封邮件join-us@wyjs.fun